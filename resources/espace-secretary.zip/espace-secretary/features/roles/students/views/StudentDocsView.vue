<script setup lang="ts">
import { Button, Card, EmptyState } from '@shared/components';
// import { CpfItem } from './partials';
import ViewContainer from './ViewContainer.vue';
import { NoteIcon, ContractIcon } from '@adersolutions/icons';
import { routes } from '@espace-admin/routes';

defineProps({
    user: {
        type: Object,
        default: () => ({}),
    },
    studentContract: {
        type: Object,
        default: () => ({}),
    },
    evaluation: {
        type: Object,
        default: () => ({}),
    },
});
</script>
<template>
    <ViewContainer :user="user">
        <div class="p-5 max-w-lg mx-auto w-full grid md:grid-cols-2 gap-5">
            <Card block>
                <EmptyState
                    :title="studentContract ? 'Contract disponible' : 'Aucun contract'"
                    :class="['pb-4 pt-2', studentContract ? 'text-green-500' : '']"
                    :image="ContractIcon"
                >
                    <p class="font-bold">
                        {{
                            studentContract ? 'Voir le contract de premiere séance' : "Vous n'avez pas encore le contrat pour cet condidat"
                        }}.
                    </p>
                    <Button
                        v-if="studentContract"
                        class="mt-4"
                        variant="success"
                        external
                        :href="route(routes.pdf.contract, studentContract.id)"
                    >
                        Voir le contrat
                    </Button>
                </EmptyState>
            </Card>
            <!-- // evaluations -->
            <Card block>
                <EmptyState
                    :title="evaluation ? 'Fiche d\'evaluation disponible' : 'Aucun Fiche d\'evaluation disponible'"
                    :class="['pb-4 pt-2', evaluation ? 'text-indigo-500' : '']"
                    :image="NoteIcon"
                >
                    <p class="font-bold">
                        {{ evaluation ? "Voir le detail d'evaluations" : "Vous n'avez pas encore une évaluation pour cet condidat" }}.
                    </p>
                    <Button v-if="evaluation" class="mt-4" variant="indigo" external :href="route(routes.pdf.evaluations, evaluation.id)">
                        Voir l'évaluation
                    </Button>
                </EmptyState>
            </Card>
        </div>
    </ViewContainer>
</template>
