<script setup lang="ts">
import {
    Alerts,
    Back,
    ButtonGroup,
    Card,
    ColorField,
    EditorField,
    FileLibrary,
    InputField,
    Select,
    SingleImageField,
    Switch,
    TabSwitch,
} from '@shared/components';
import {routes} from '@espace-admin/routes.js';
import {computed, PropType} from 'vue';
import {useForm} from '@inertiajs/vue3';
import {LearningModeList, OffreCategoryList, OffreTypeList} from '@common/enums';
import {useFiles} from '@shared/hooks';
import {OfferType} from '@common/types';
import {ButtonType} from '@shared/types';

const props = defineProps({
    data: {
        type: Object as PropType<OfferType>,
        default: () => ({}),
    },
    actions: Array,
    isEdit: Boolean,
});

const heading = props.isEdit ? 'Modifier offre' : 'Nouvelle offre';
const medias = useFiles();

const form = useForm({
    name: props.data.name || '',
    caracteristiques: props.data.caracteristiques || '',
    description: props.data.description || '',
    color: props.data.color || '#000000',
    price_ht: props.data.price_ht || '',
    original_price: props.data.original_price || '',
    discounted_price: props.data.discounted_price || '',
    second_price: props.data.second_price || '',   // ✅ NEW
    balance: props.data.balance || '',
    balance_2: props.data.balance_2 || '',         // ✅
    multi_payment: props.data.multi_payment || undefined,
    agency_name: props.data.agency_name || '',     // ✅ NEW
    is_auto: props.data.is_auto || false,
    is_cpf: props.data.is_cpf || false,
    is_evaluation: props.data.is_evaluation || false,
    type_offre: props.data.type_offre || '',
    type: props.data.type || '',
    status: props.data.status || false,
    is_offer_cart: props.data.is_offer_cart || false,
    media: props.data?.media?.storage_media || null,
    order: props.data.order,
});


const actions = computed<ButtonType[]>(() => [
    {
        label: `${props.isEdit ? 'Modifier' : 'Ajouter'} offre`,
        variant: 'primary',
        full: true,
        submit: true,
        disabled: !form.isDirty,
        loading: form.processing,
        onAction: submit,
    },
    {
        label: 'Abandonner',
        disabled: !form.isDirty,
        variant: 'secondary',
        full: true,
        onAction: () => form.reset(),
    },
]);
const submit = () => {
    form.transform((data: any) => {
        if (data.media?.id) {
            data.media = data.media.id;
        }
        if (data.is_cpf) {
            data.status = false;
        }
        data.final_price = data.discounted_price || data.original_price;
        return data;
    });
    if (props.isEdit) {
        form.put(route(routes.shop.offers.update, props.data.id));
    } else {
        form.post(route(routes.shop.offers.store));
    }
};

const onDeleteFile = () => {
    if (props.isEdit && props.data.media?.id) {
        medias.delete(props.data.media.id).then(() => {
            form.media = null;
        });
    } else {
        form.media = null;
    }
};
</script>

<template>
    <form class="form-page" @submit.prevent="submit">
        <FileLibrary @submit="form.media = $event"/>
        <Back :title="heading" :back="route(routes.shop.offers.index)"/>

        <article class="left-form">
            <Back :title="heading" :back="route(routes.shop.offers.index)"/>
            <div class="form-content">
                <Alerts/>
                <Card block padding title="Detail offre">
                    <InputField v-model="form.name" :error="form.errors.name" label="Nom du produit"/>
                    <InputField
                        v-model="form.description"
                        :error="form.errors.description"
                        :multiline="3"
                        label="Description du produit "
                    />
                    <EditorField v-model="form.caracteristiques" label="Caractéristiques"
                                 :error="form.errors.caracteristiques"/>
                    <!-- <InputField v-model="form.caracteristiques" :error="form.errors.caracteristiques" :multiline="3" /> -->
                    <div class="grid md:grid-cols-2 gap-5">
                        <Select
                            v-model="form.type"
                            :items="Object.values(OffreCategoryList)"
                            :error="form.errors.type"
                            :keys="['name', 'id']"
                            :show-search="false"
                            :default-value="OffreCategoryList[data?.type]"
                            label="Type"
                            clear
                            placeholder="Choisir type de produit"
                        />
                        <Select
                            v-model="form.type_offre"
                            :error="form.errors.type_offre"
                            :items="Object.values(OffreTypeList)"
                            :keys="['name', 'id']"
                            :default-value="OffreTypeList[data?.type_offre] || ''"
                            :show-search="false"
                            label="Type d'offre"
                            clear
                        />
                    </div>
                    <div class="flex items-center justify-between">
                        <label class="block font-medium text-xs text-gray-600 mb-0.5 mt-1"> Mode
                            d'apprentissage </label>
                        <TabSwitch v-model="form.is_auto" class="text-xs" size="sm" short
                                   :items="Object.values(LearningModeList)"/>
                    </div>
                    <div class="flex items-center justify-between">
                        <label class="block font-medium text-xs text-gray-600 mb-0.5 mt-1">Offre Cpf </label>
                        <Switch v-model="form.is_cpf" class="text-xs bg-gray-200" size="sm"/>
                    </div>
                    <div class="flex items-center justify-between">
                        <label class="block font-medium text-xs text-gray-600 mb-0.5 mt-1">Heure de
                            l'évaluation </label>
                        <Switch v-model="form.is_evaluation" class="text-xs bg-gray-200" size="sm"/>
                    </div>
                </Card>
                <Card block padding title="Prix">
                    <div class="grid md:grid-cols-2 gap-3">
                        <InputField v-model="form.price_ht" :error="form.errors.price_ht" label="Prix HT" suffix="€"
                                    type="number"/>
                        <InputField
                            v-model="form.original_price"
                            :error="form.errors.original_price"
                            label="Prix de base (TTC)"
                            suffix="€"
                            type="number"
                        />
                        <InputField
                            v-model="form.discounted_price"
                            :error="form.errors.discounted_price"
                            label="Le prix après réduction"
                            type="number"
                        />
                        <InputField v-model="form.balance" :error="form.errors.balance" label="Balance" suffix="H"
                                    type="number"/>

                                        <InputField v-model="form.balance_2" :error="form.errors.balance_2" label="Balance (2)" suffix="H" type="number"/>

                        <InputField
                            v-model="form.multi_payment"
                            :error="form.errors.multi_payment"
                            label="Tranche de paiement"
                            type="number"
                        />

                         <!-- <InputField
                            v-model="form.multi_payment"
                            :error="form.errors.multi_payment"
                            label="Agency Name"
                            type="text"
                        /> -->

                          <InputField v-model="form.second_price" :error="form.errors.second_price" label="Deuxième prix" suffix="€" type="number"/>

                              <InputField v-model="form.agency_name" :error="form.errors.agency_name" label="Nom de l’agence" type="text"/>

                    </div>
                </Card>
            </div>
            <ButtonGroup vertical class="form-actions" :actions="actions"/>
        </article>
        <article class="right-form">
            <div>
                <ColorField v-model="form.color" :error="form.errors.color" label="Couleur"/>
                <Switch v-model="form.is_offer_cart" :error="form.errors.is_offer_cart" label="C'est offre de Pannier"/>
                <Switch v-model="form.status" :disabled="form.is_cpf" :error="form.errors.status" label="Activé "/>
                <SingleImageField :error="form.errors.media" :src="form.media?.path || form.media || undefined"
                                  @delete="onDeleteFile"/>
                <InputField
                    v-model="form.order"
                    :error="form.errors.order"
                    label="Ordre d'affichage"
                    min="0"
                    type="number"
                />
            </div>
            <ButtonGroup vertical class="form-actions" :actions="actions"/>
        </article>
    </form>
</template>
