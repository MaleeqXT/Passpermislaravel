<script setup lang="ts">
import { Back, Badge, Page } from '@shared/components';
import { DialogConfirm } from '@shared/components';
import { routes } from '@espace-admin/routes';
import { ref } from 'vue';
import FeedsAndStatusCart from './FeedsAndStatusCart.vue';
import { CustomerCard, OffersCard, StatsSection } from '../commandes/partials';
import { CartType } from '@common/types';
import { CartStatus } from '@common/enums';

type PropsType = {
    cart: CartType;
};
const props = defineProps<PropsType>();
const confirmation = ref(null);
const deleting = ref(false);
const onConfirmedDelete = () => {
    deleting.value = true;
};
</script>

<template>
    <Page width="full" padding="none">
        <div class="form-page">
            <!--  -->
            <article class="left-form">
                <Back :title="`${cart.student?.user?.name}`" :back="route(routes.shop.cart.index)" />
                <div class="form-content">
                    <Alerts />
                    <StatsSection :data="cart" />
                    <div class="rainbow"></div>
                    <OffersCard :items="{ data: cart?.cart_details }" />
                </div>
                <!-- <ButtonGroup vertical class="form-actions" :actions="actions" /> -->
            </article>
            <article class="right-form text-sm">
                <div>
                    <h3 class="font-bold">Paiements</h3>
                    <ul class="flex flex-col gap-3 bg-gray-100 rounded-lg p-3 !mt-2">
                        <li>
                            <p class="opacity-50">ID de panier</p>
                            <span class="">{{ cart.id }}</span>
                        </li>
                        <li>
                            <p class="opacity-50">Pannier Statut</p>
                            <Badge :id="cart.status" :options="CartStatus" />
                        </li>
                    </ul>
                    <CustomerCard :student="cart.student" />
                </div>
                <!-- <ButtonGroup vertical class="form-actions" :actions="actions" /> -->
            </article>
        </div>
        <!-- <StatsSection :data="cart" />
        <section class="grid md:grid-cols-3 grid-cols-2 gap-5">
            <article class="col-span-2 order-last md:order-first">
                <FeedsAndStatusCart :data="props.cart" />
                <OffersCard :items="{ data: cart?.cart_details }" />
            </article>
            <UserCard :student="cart?.student" class="col-span-2 md:col-span-1 order-first md:order-last" />
        </section>
        <DialogConfirm :loading="deleting" :show="!!confirmation" @close="confirmation = null" @confirm="onConfirmedDelete">
            Etes-vous sûr que vous voulez supprimer cette pannier
            <b class="text-red-500">{{ confirmation?.title }}</b>
            ?
        </DialogConfirm> -->
    </Page>
</template>
