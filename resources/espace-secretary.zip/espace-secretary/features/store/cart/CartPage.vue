<script setup lang="ts">
import { DeleteIcon } from '@adersolutions/icons';
import { getTotalBalance, getCartTotal } from '@espace-admin/utils';
import { routes } from '@espace-admin/routes';
import { ViewIcon } from '@adersolutions/icons';
import { CartStatusEnum, CartStatus } from '@common/enums';
import { dateFormat, moneyFormat } from '@shared/utils';
import { ItemsCopy } from '@common/components';
import { Card, Filters, Thumb, Badge, Page, DataTable } from '@shared/components';
import { headings } from './cart';
import { BulkActionType, DataListType } from '@shared/types';
import { CartType } from '@common/types';

type PropsType = {
    carts: DataListType<CartType[]>;
};

defineProps<PropsType>();

const bulkActions: BulkActionType[] = [
    {
        label: 'Voir détails',
        icon: ViewIcon,
        variant: 'secondary',
        isLink: true,
        onAction: (item) => route(routes.shop.cart.show, item.id),
    },
    {
        label: 'Supprimer',
        icon: DeleteIcon,
        variant: 'danger',
        confirm: {
            url: routes.shop.cart.delete,
        },
    },
];


// ✅ Total price: respect second_price if selected
const getTotalPrice = (items = []) => {
    let total = 0;
    items?.forEach((item) => {
        const offer = item.offer ?? item;
        const selected = item.selected_price_type ?? offer.selected_price_type ?? 'final';
        const price =
            selected === 'second'
                ? offer.second_price ?? offer.final_price ?? 0
                : offer.final_price ?? offer.second_price ?? 0;

        total += Number(price);
    });
    return total;
};

// ✅ Total balance: respect balance_2 if second selected
const getTotalBalanceLocal = (items = []) => {
    let total = 0;
    items?.forEach((item) => {
        const offer = item.offer ?? item;
        const selected = item.selected_price_type ?? offer.selected_price_type ?? 'final';
        const bal =
            selected === 'second'
                ? offer.balance_2 ?? offer.balance ?? 0
                : offer.balance ?? offer.balance_2 ?? 0;

        total += Number(bal);
    });
    return total;
};

</script>

<template>
    <Page title="Pannier" width="xl">
        <Card block>
            <div>
                <Filters :tabs="[{ name: 'Tous', id: '' }, ...Object.values(CartStatus)]" default-tab="" key-tab="status" />

                <DataTable v-slot="{ item }" :headings="headings" :items="carts" :bulk-actions="bulkActions">
                    <td class="cell">
                        <div class="flex gap-2 items-center">
                            <Thumb :src="item.student?.user?.media || item.student?.user?.profile_photo_url" size="xs" />
                            <b>{{ item.student?.user?.name }}</b>
                        </div>
                    </td>

                    <td class="cell">
                        <ItemsCopy class="!gap-0" :email="item?.student?.user.email" :phone="item?.student?.user.phone" />
                    </td>

                    <td class="cell">{{ item.cart_details?.length }} offers</td>

                    <!-- ✅ Use new total balance -->
                    <td class="cell">{{ getTotalBalanceLocal(item.cart_details) }} h</td>

                    <!-- ✅ Use new total price -->
                    <td class="cell">
                        {{ moneyFormat(getTotalPrice(item.cart_details)) }}
                    </td>

                    <td class="cell capitalize">
                        {{ dateFormat(item.created_at, 'fr') }}
                        {{ dateFormat(item.created_at, 'shortTime') }}
                    </td>

                    <td class="cell">
                        <Badge :id="item.status" :options="CartStatus" />
                    </td>
                </DataTable>
            </div>
        </Card>
    </Page>
</template>

