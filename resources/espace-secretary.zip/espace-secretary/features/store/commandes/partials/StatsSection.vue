<template>
    <div class="bg-dark rounded-xl overflow-hidden bg-rainbow rainbow-opacity-30">
        <div class="mx-auto max-w-7xl">
            <div class="grid grid-cols-1 gap-px bg-white/5 sm:grid-cols-2">
                <div v-for="stat in stats" :key="stat.name" class="bg-dark px-4 py-3 sm:px-6 lg:px-8">
                    <p class="text-sm font-medium leading-6 text-gray-400">{{ stat.name }}</p>
                    <p class="mt-2 flex items-baseline gap-x-2">
                        <span class="font-semibold tracking-tight text-white" :class="stat.name === 'DATE' ? 'text-2xl' : 'text-4xl'">{{
                            stat.value
                        }}</span>
                    </p>
                </div>
            </div>
        </div>
    </div>
</template>
<script setup lang="ts">
import { dateFormat } from '@shared/utils';
import { getTotalBalance } from '@espace-admin/utils';

const props = defineProps({
    data: {
        type: Object,
        default: () => ({}),
    },
});

// ✅ Total price: respect second_price if selected
const getTotalPrice = (items = []) => {
    let total = 0;
    items?.forEach((item) => {
        const offer = item.offer ?? item;
        const selected = item.selected_price_type ?? offer.selected_price_type ?? 'final';
        const price =
            selected === 'second'
                ? offer.second_price ?? offer.final_price ?? 0
                : offer.final_price ?? offer.second_price ?? 0;

        total += Number(price);
    });
    return total;
};

// ✅ Total balance: respect balance_2 if second selected
const getTotalBalanceLocal = (items = []) => {
    let total = 0;
    items?.forEach((item) => {
        const offer = item.offer ?? item;
        const selected = item.selected_price_type ?? offer.selected_price_type ?? 'final';
        const bal =
            selected === 'second'
                ? offer.balance_2 ?? offer.balance ?? 0
                : offer.balance ?? offer.balance_2 ?? 0;

        total += Number(bal);
    });
    return total;
};

const stats = [
    { name: 'Montant', value: getTotalPrice(props.data?.cart_details) + ' €' },
    { name: 'Balance', value: getTotalBalanceLocal(props.data?.cart_details) + 'H' },
];
</script>
