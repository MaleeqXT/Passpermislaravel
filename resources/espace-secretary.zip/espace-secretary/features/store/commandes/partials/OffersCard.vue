<script setup lang="ts">
import { Button, Thumb } from '@shared/components';
import { routes } from '@espace-admin/routes';
import { ref } from 'vue';
import { ReceiptRefundIcon } from '@adersolutions/icons';
import { PaymentTypeEnum, PaymentStatusEnum } from '@common/enums';
import { useAlert } from '@shared/stores';
import { getFilePath, moneyFormat } from '@shared/utils';
import { Link } from '@inertiajs/vue3';
import { SizeEnum } from '@shared/enums';

const props = defineProps({
    items: {
        type: Object,
        default: () => ({}),
    },
    isOrder: {
        type: Boolean,
    },
    paymentInfo: {
        type: Object,
        method: String,
        status: String,
    },
    orderId: String,
});
const inProgress = ref(false);
const alert = useAlert();

const headings = [
    { name: 'Produit', colspan: '2' },
    { name: 'Prix', className: 'text-center font-normal px-3' },
    { name: 'Qtn', className: 'text-center font-normal px-3' },
    { name: 'Heures', className: 'text-center font-normal px-3' },
    { name: 'Tranches', className: 'text-center font-normal px-3' },
    { name: 'Total Payé', className: 'text-center font-normal px-3' },
    {
        name: props.isOrder && props.paymentInfo?.method === PaymentTypeEnum.STRIPE ? 'Action' : null,
        className:
            props.isOrder && props.paymentInfo?.method === PaymentTypeEnum.STRIPE ? 'text-center pr-4 sticky right-0 bg-slate-100' : null,
    },
];
const submit = async (id) => {
    inProgress.value = true;
    const data = {
        offer_id: id,
    };
    await axios
        .post(route(routes.shop.commandes.refund, props.orderId), data)
        .then(() => {
            alert.show({ type: 'success', title: 'Refunded' });
        })
        .catch(() => {
            alert.show({ type: 'error', title: 'an error happend' });
        });
    inProgress.value = false;
};
const isRefundAvailable = () => {
    return !(props.paymentInfo.status !== PaymentStatusEnum.PAID || props.paymentInfo.method !== PaymentTypeEnum.STRIPE);
};
</script>

<template>
    <section class="my-5">
        <h3 class="font-bold mb-2">Offer cyuommandé</h3>

        <ul class="text-sm space-y-2">
            <li v-for="item in items.data" :key="item.id" class="flex gap-10 bg-white box">
                <div class="flex-1 flex gap-2 h-[106px]">
                    <img
                        class="object-cover aspect-square h-full rounded-l-xl"
                        :src="getFilePath(item.offer?.media, true)"
                        @error="(e) => ((e.target as HTMLImageElement).src = '/assets/images/placeholder.png')"
                    />
                    <div class="flex-1 py-2">
                        <Link class="btn btn-link btn-dark !pl-0" :href="route(routes.shop.offers.edit, item.offer.id)">
                            {{ item.offer.name }}
                        </Link>
                        <p class="mb-3 text-xs opacity-70">
                            {{ item.offer.description }}
                        </p>
                        <Button v-if="isOrder" variant="danger" class="h-6" :disabled="!isRefundAvailable()" @click="submit(item.offer.id)">
                            {{ isRefundAvailable() ? 'Rembourser' : '' }}
                        </Button>
                    </div>
                </div>

        <dl class="w-1/3 divide-y divide-gray-200 text-xs py-1 px-3">
<!-- ✅ Balance -->
<div class="flex items-center justify-between py-1">
    <dt class="text-gray-600">Balance</dt>
    <dd class="font-medium text-gray-900">
        {{
            item.selected_price_type === 'second'
                ? (item.offer.balance_2 ? Math.floor(item.offer.balance_2) : (item.offer.balance ?? 0))
                : (item.offer.balance ?? (item.offer.balance_2 ? Math.floor(item.offer.balance_2) : 0))
        }}h
    </dd>
</div>


    <!-- ✅ Tranches -->
    <div class="flex items-center justify-between py-1">
        <dt class="text-gray-600">Tranches</dt>
        <dd class="font-medium text-gray-900">{{ item.tranches }}</dd>
    </div>

    <!-- ✅ Prix de base (original price) -->
    <div class="flex items-center justify-between py-1">
        <dt class="text-gray-600">Prix de base</dt>
        <dd class="font-medium text-gray-900">
            {{
                moneyFormat(
                    item.selected_price_type === 'second'
                        ? (item.offer.second_price ?? item.offer.original_price ?? 0)
                        : (item.offer.original_price ?? item.offer.original_second_price ?? 0)

                )
            }}

        </dd>
    </div>

    <!-- ✅ Montant payé (actual final or second) -->
    <div class="flex items-center justify-between py-1">
        <dt class="text-gray-600">Montant payé</dt>
        <dd class="font-medium text-gray-900">
            {{
                moneyFormat(
                    item.selected_price_type === 'second'
                        ? (item.offer.second_price ?? item.offer.final_price ?? 0)
                        : (item.offer.final_price ?? item.offer.second_price ?? 0)
                )
            }}
        </dd>
    </div>
</dl>



            </li>
        </ul>
    </section>
</template>
