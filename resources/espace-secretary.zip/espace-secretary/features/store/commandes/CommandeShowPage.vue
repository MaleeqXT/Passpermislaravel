<script setup lang="ts">
import { Alerts, Back, Badge, Card, Page } from '@shared/components';
import { routes } from '@espace-admin/routes';
import { ref } from 'vue';
import { OffersCard, StatsSection, CustomerCard } from './partials';
import { CommandeType } from '@common/types';
import { PaymentStatus, PaymentType } from '@common/enums';
type PropsType = {
    sale: CommandeType;
};
defineProps<PropsType>();
// const confirmation = ref(null);
const deleting = ref(false);

const onConfirmedDelete = () => {
    deleting.value = true;
};
</script>

<template>
    <Page width="full" padding="none">
        <div class="form-page">
            <!--  -->
            <article class="left-form">
                <Back
                    :badges="[PaymentStatus[sale.payment_status]]"
                    :title="`#${sale.reference}`"
                    :back="route(routes.shop.commandes.index)"
                />
                <div class="form-content">
                    <Alerts />
                    <StatsSection :data="sale?.cart" />
                    <div class="rainbow"></div>
                    <OffersCard
                        :items="{ data: sale.cart?.cart_details }"
                        :order-id="sale.id"
                        :payment-info="{ method: sale.payment_method, status: sale.payment_status }"
                        is-order
                    />
                </div>
                <!-- <ButtonGroup vertical class="form-actions" :actions="actions" /> -->
            </article>
            <article class="right-form text-sm">
                <div>
                    <h3 class="font-bold">Paiements</h3>
                    <ul class="flex flex-col gap-3 bg-gray-100 rounded-lg p-3 !mt-2">
                        <li>
                            <p class="opacity-50">N° de commande</p>
                            <span class="">{{ sale.reference }}</span>
                        </li>
                        <li>
                            <p class="opacity-50">Paiement ID</p>
                            <span class="">{{ sale.payment_id }}</span>
                        </li>

                        <li>
                            <p class="opacity-50">Payment Method</p>
                            <span class="font-semibold block mt-1">{{ PaymentType[sale.payment_method].name }}</span>
                        </li>
                        <li>
                            <p class="opacity-50">Payment Status</p>
                            <Badge :id="sale.payment_status" :options="PaymentStatus" />
                        </li>
                    </ul>
                    <CustomerCard :student="sale?.student" />
                </div>
                <!-- <ButtonGroup vertical class="form-actions" :actions="actions" /> -->
            </article>
        </div>
        <!--         
        <DialogConfirm :loading="deleting" :show="!!confirmation" @close="confirmation = null" @confirm="onConfirmedDelete">
            Etes-vous sûr que vous voulez supprimer la commande
            <b class="text-red-500">{{ confirmation?.title }}</b>
            ?
        </DialogConfirm> -->
    </Page>
</template>
